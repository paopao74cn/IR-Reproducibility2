#if !defined(KEY_CONST_H)
#define KEY_CONST_H

#define kf_min_fcb_lc 43376
#define kf_block_lc   4096
#define kf_buffer_lc  4160

#endif
